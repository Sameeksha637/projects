package com.example.user.myfirsstproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

     EditText txtnum1, txtnum2;
     Button btnplus, btnminus, btnmult, btndiv;
     TextView lblresult;                            //This is declaration

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtnum1 = findViewById(R.id.num1);             // connecting  front to back end
        txtnum2 = findViewById(R.id.num2);
        btnplus = findViewById(R.id.btnplus);
        btnminus = findViewById(R.id.btnminus);
        btnmult = findViewById(R.id.btnmult);
        btndiv = findViewById(R.id.btndiv);
        lblresult = findViewById(R.id.lblresult);

        btnplus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String num1 = txtnum1.getText().toString();
                String num2 = txtnum2.getText().toString();
                if(num1.equals("") || num2.equals(""))
                {
                    Toast.makeText(getApplicationContext(),"Fields are empty.",Toast.LENGTH_SHORT).show();
                }
                else {
                       Double t = Double.parseDouble(num1) + Double.parseDouble(num2);
                       lblresult.setText(lblresult.toString());
                }
                }

            }
        });

        btnminus.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

            String num1 = txtnum1.getText().toString();
            String num2 = txtnum2.getText().toString();
            if(num1.equals("") || num2.equals(""))
            {
                Toast.makeText(getApplicationContext(),"Fields are empty.",Toast.LENGTH_SHORT).show();
            }
            else {
                Double t = Double.parseDouble(num1) - Double.parseDouble(num2);
                lblresult.setText(lblresult.toString());
            }

            }
        });

         btnmult.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){

            String num1 = txtnum1.getText().toString();
            String num2 = txtnum2.getText().toString();
            if(num1.equals("") || num2.equals(""))
            {
                Toast.makeText(getApplicationContext(),"Fields are empty.",Toast.LENGTH_SHORT).show();
            }
            else {
                Double t = Double.parseDouble(num1) * Double.parseDouble(num2);
                lblresult.setText(lblresult.toString());
            }

        }
    });

          btndiv.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view){

            String num1 = txtnum1.getText().toString();
            String num2 = txtnum2.getText().toString();
            if(num1.equals("") || num2.equals(""))
            {
                Toast.makeText(getApplicationContext(),"Fields are empty.",Toast.LENGTH_SHORT).show();
            }
            else {

                Double num1 = Double.parseDouble(num1);
                Double num2 = Double.parseDouble(num2);

                if(num2 == 0) {
                Toast.makeText(getApplicationContext(), "Divide by zero error",Toast.LENGTH_SHORT).show();
                }
                else {
                    Double result = num1/num2;
                    lblresult.setText(result.toString());
                }
            }

        }
    });




    }
}

package com.example.user.myapplication;

import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class volactivity extends AppCompatActivity {
    Button bx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volactivity);
    /*bx=(Button)findViewById(R.id.button2);
    bx.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          Intent intent=new Intent(getApplicationContext(),volactivity.class);
            PendingIntent pi=PendingIntent.getActivity(getApplicationContext(),0,intent,0);
            SmsManager sms=SmsManager.getDefault();
            sms.sendTextMessage("9206721626",null,"hello world",pi,null);
            Toast.makeText(getApplicationContext(),"send successfully",Toast.LENGTH_SHORT).show();
        }
    });
*/    }
}

package com.example.user.myapplication;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class custactivity extends AppCompatActivity {
    Button bsms;

EditText s1,s2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custactivity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        s1=(EditText)findViewById(R.id.msgg1);
        s2=(EditText)findViewById(R.id.add1);

bsms =(Button)findViewById(R.id.ssmm1);

bsms.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
String msg="Help type:"+s1.getText().toString()+"  location:"+s2.getText().toString();
        Intent intent=new Intent(getApplicationContext(),custactivity.class);
        PendingIntent pi=PendingIntent.getActivity(getApplicationContext(),0,intent,0);
        SmsManager sms=SmsManager.getDefault();
        sms.sendTextMessage("8317442983",null,msg,pi,null);
        sms.sendTextMessage("8123923236",null,msg,pi,null);
        sms.sendTextMessage("8296763798",null,msg,pi,null);
        sms.sendTextMessage("8660220729",null,msg,pi,null);
        sms.sendTextMessage("8095559264",null,msg,pi,null);

        Toast.makeText(getApplicationContext(),"send successfully",Toast.LENGTH_SHORT).show();
    }
});
    }

}
